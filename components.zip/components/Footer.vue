<template>
	<div class='footer'>
		<footer>
			<div class='footer'>
				<p class='first'>
					<span class='contact'> 前端微信公众号:</span><a href="javascript:;">xxxxx</a>
					<span class='contact'> 前端微博:</span><a href="javascript:;">xxxxx</a>
				</p>
				<p class='friend-link'>
					<span class='contact'> 友情链接：</span><a href="javascript:;">xxxxx</a>
					<a href="javascript:;">xxxxx</a><a href="javascript:;">xxxxx</a>
				</p>
				<p class='learn-source'>
					<span class='contact'> 资源：</span><a href="javascript:;">xxxxx</a>
					<a href="javascript:;">xxxxx</a>
				</p>
				<p class='copyright'>
					<a href="javascript:;">©2017 xxxxx </a>
					<a href="javascript:;">使用在线教育前必读 </a>
					<a href="javascript:;">意见反馈</a>
					<span>京ICP证xxxxxxxx号 </span>
				</p>
			</div>
		</footer>
	</div>
</template>
<style scoped>
footer{
	font-size: 14px;
    padding: 20px;
    color: #fff;
    width: 100%;
    height: 100px;
    background: url(../assets/img/footer.png);
    -webkit-background-size: 100% 100%;
    background-size: 100% 100%;
}
footer a{ color: #fff; padding-left: 10px;}
.footer p{ line-height: 26px; }
.footer{
	text-align: center;
}
</style>